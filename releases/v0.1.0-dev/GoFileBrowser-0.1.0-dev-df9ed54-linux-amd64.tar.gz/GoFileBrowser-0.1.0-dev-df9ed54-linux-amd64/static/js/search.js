const searchForm = document.getElementById('search_form');
if (searchForm) {
    searchForm.addEventListener('submit', function (e) {
        e.preventDefault();
    });
}

document.addEventListener('click', function (event) {
    const target = event.target;
    const menu = document.getElementById('search-data-choice-menu');
    const toggle = target.closest ? target.closest('.menu-toggle') : null;

    if (toggle) {
        event.stopPropagation(); // 阻止冒泡，避免触发到 document 上
        if (!menu) return;
        const rect = toggle.getBoundingClientRect();
        const menuRect = menu.getBoundingClientRect();
        const gap = 6;
        const padding = 10;

        // 菜单右对齐到按钮，空间不足时再向左收。
        let left = rect.right - menuRect.width;
        if (left < padding) left = padding;
        if (left + menuRect.width > window.innerWidth - padding) {
            left = window.innerWidth - menuRect.width - padding;
        }

        let top = rect.bottom + gap;
        if (top + menuRect.height > window.innerHeight - padding) {
            top = rect.top - menuRect.height - gap;
        }
        if (top < padding) top = padding;

        menu.style.left = `${left}px`;
        menu.style.top = `${top}px`;

        menu.dataset.link = toggle.dataset.link;
        menu.dataset.path = toggle.dataset.path;
        menu.dataset.preview = toggle.dataset.preview || "";
        menu.dataset.archive = toggle.dataset.archive || "";
        menu.dataset.archiveTgz = toggle.dataset.archiveTgz || "";
        menu.dataset.isdir = toggle.dataset.isdir || "false";

        const isDir = menu.dataset.isdir === "true";
        menu.querySelectorAll('.menu-file').forEach((item) => {
            item.style.display = isDir ? 'none' : '';
        });
        menu.querySelectorAll('.menu-dir').forEach((item) => {
            item.style.display = isDir ? '' : 'none';
        });

        const previewItem = menu.querySelector('.menu-preview');
        if (previewItem && !isDir) {
            previewItem.style.display = menu.dataset.preview ? '' : 'none';
        }

        menu.classList.add('show');
        toggle.setAttribute('aria-expanded', 'true');
        return;
    }

    const menuItem = target.closest ? target.closest('.choice-menu [role="menuitem"]') : null;
    if (menuItem) {
        event.stopPropagation(); // 阻止冒泡
        closeSearchMenu();

        if (menuItem.classList.contains('menu-preview')) {
            if (menu.dataset.preview) {
                window.location.href = menu.dataset.preview;
            }
            return;
        }

        if (menuItem.classList.contains('menu-zip')) {
            window.location.href = menu.dataset.archive;
            return;
        }

        if (menuItem.classList.contains('menu-tgz')) {
            window.location.href = menu.dataset.archiveTgz;
            return;
        }

        if (menuItem.classList.contains('menu-download')) {
            window.location.href = menu.dataset.link;
        }

        if (menuItem.classList.contains('menu-copy')) {
            copyToClipboard(window.location.origin + menu.dataset.link);
        }

        if (menuItem.classList.contains('menu-md5')) {
            if (menu.dataset.isdir === "true") {
                Swal.fire({
                    title: '提示',
                    text: '无法对目录计算哈希值',
                    icon: 'warning'
                });
                return;
            }
            const filePath = menu.dataset.path;
            Swal.fire({
                title: '计算 MD5',
                text: '正在计算 MD5，请稍候...',
                allowOutsideClick: false,
                didOpen: () => {
                    Swal.showLoading();
                }
            });
            const start = Date.now();
            fetch(`/hash${encodeURIComponent(filePath)}?type=md5`)
                .then(response => response.json())
                .then(data => {
                    const duration = Date.now() - start;
                    const delay = Math.max(0, 500 - duration);
                    setTimeout(() => {
                        if (data.hash) {
                            Swal.fire({
                                title: '计算 MD5',
                                html: `
                            <div class="swal-hash-content">
                                <div><span class="swal-hash-label">Name:</span> ${escapeHtml(data.filename)}</div>
                                <div><span class="swal-hash-label">Path:</span> ${escapeHtml(data.filepath)}</div>
                                <div><span class="swal-hash-label">Hash:</span> ${escapeHtml(data.hash)}</div>
                            </div>`,
                                customClass: {
                                    htmlContainer: 'swal-window-left',
                                    popup: 'swal-wide-popup'
                                }
                            });
                        } else if (data.error) {
                            Swal.fire({ icon: 'error', title: '错误', text: String(data.error) });
                        }
                    }, delay);
                })
                .catch(error => {
                    Swal.fire({ icon: 'error', title: '请求失败', text: String(error) });
                });
        }

        if (menuItem.classList.contains('menu-sha256')) {
            if (menu.dataset.isdir === "true") {
                Swal.fire({
                    title: '提示',
                    text: '无法对目录计算哈希值',
                    icon: 'warning'
                });
                return;
            }
            const filePath = menu.dataset.path;
            Swal.fire({
                title: '计算 SHA256',
                text: '正在计算 SHA256，请稍候...',
                allowOutsideClick: false,
                didOpen: () => {
                    Swal.showLoading();
                }
            });
            const start = Date.now();
            fetch(`/hash${encodeURIComponent(filePath)}?type=sha256`)
                .then(response => response.json())
                .then(data => {
                    const duration = Date.now() - start;
                    const delay = Math.max(0, 500 - duration);
                    setTimeout(() => {
                        if (data.hash) {
                            Swal.fire({
                                title: '计算 SHA256',
                                html: `
                            <div class="swal-hash-content">
                                <div><span class="swal-hash-label">Name:</span> ${escapeHtml(data.filename)}</div>
                                <div><span class="swal-hash-label">Path:</span> ${escapeHtml(data.filepath)}</div>
                                <div><span class="swal-hash-label">Hash:</span> ${escapeHtml(data.hash)}</div>
                            </div>`,
                                customClass: {
                                    htmlContainer: 'swal-window-left',
                                    popup: 'swal-wide-popup'
                                }
                            });
                        } else if (data.error) {
                            Swal.fire({ icon: 'error', title: '错误', text: String(data.error) });
                        }
                    }, delay);
                })
                .catch(error => {
                    Swal.fire({ icon: 'error', title: '请求失败', text: String(error) });
                });
        }
        return;
    }

    // 点击页面空白区域，关闭菜单
    if (menu && menu.classList.contains('show')) {
        closeSearchMenu();
    }
});

function closeSearchMenu() {
    const menu = document.getElementById('search-data-choice-menu');
    if (menu) {
        menu.classList.remove('show');
    }
    document.querySelectorAll('.menu-toggle[aria-expanded="true"]').forEach((button) => {
        button.setAttribute('aria-expanded', 'false');
    });
}

document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape') {
        closeSearchMenu();
    }
});

window.addEventListener('scroll', closeSearchMenu, { passive: true });


function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, function (ch) {
        return {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#39;'
        }[ch];
    });
}

function copyToClipboard(text) {
    if (navigator.clipboard) {
        navigator.clipboard.writeText(text).then(() => {
            Swal.fire({
                title: "复制成功!",
                icon: "success",
                draggable: true
            });
        }).catch(err => {
            alert('复制失败: ' + err);
        });
    } else {
        // 降级方案
        const textarea = document.createElement('textarea');
        textarea.value = text;
        document.body.appendChild(textarea);
        textarea.select();
        try {
            document.execCommand('copy');
            Swal.fire({
                title: "复制成功!",
                icon: "success",
                draggable: true
            });
        } catch (err) {
            alert('复制失败: ' + err);
        }
        document.body.removeChild(textarea);
    }
}