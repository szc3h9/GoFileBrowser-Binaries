# 第三方前端资源

本目录下的第三方资源全部**本地托管**，由 GoFileBrowser 通过 `/static/` 提供，
运行时**不依赖 CDN**。升级时从上游官方发布渠道取包，更新对应 `VERSION` 中的
来源、版本与校验值。

| 目录 | 版本 | 许可 | 来源 |
| --- | --- | --- | --- |
| `htmx/` | 4.0.2 | 0BSD | GitHub Release `v4.0.2` |
| `sweetalert2/` | 11.26.25 | MIT | npm `sweetalert2@11.26.25` |

约束：

- 模板中的 `<script src>` / `<link href>` 只能指向本站路径（`/static/...`）；
  `web/assets_test.go` 会做静态检查。
- 升级前端库时，在 `VERSION` 中记录来源、SHA256、兼容性与回退方式。
- 不引入运行时远程脚本、字体或样式；需要新资源时先下载到本目录。
